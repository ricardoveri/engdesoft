package Juliana;

public class Matematica {
    int numero1 = 10;
    int numero2 = 20;
    static int soma;

    public static int soma(int numero1, int numero2){
        return soma = numero1 + numero2;
    }

}

